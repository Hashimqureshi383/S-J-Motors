public class WorkshopM extends Manager implements DataDisplay.ViewReport
{
    public WorkshopM(int id,String name,String phone,String password,String address,int outletId)
    {
        super(id,name,phone,password,address,outletId);
    }
    public void runReport(Staff member)
    {

    }
    public void bookService()
    {

    }
    public void manageJobSchedule()
    {

    }
    public void predictJobLoad()
    {

    }
}
