public class FloorM extends Manager implements DataDisplay.ViewReport
{
    public FloorM(int id,String name,String phone,String password,String address,int outletId)
    {
        super(id,name,phone,password,address,outletId);
    }
    public void runReport(Staff member)
    {

    }
    public void checkJobs()
    {

    }
    public void checkStaff()
    {

    }
    public void returnItems()
    {

    }
}
