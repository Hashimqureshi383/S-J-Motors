    public class Driver
{
    public static void main(String[] args)
    {
        System.out.print("\n\t\t\tWelcome to S&J Motors\n\n");
        System.out.print("We have a vast setup of Motor Mechanics that deploys a large number of expert\n");
        System.out.print("and experienced employees along with managers having excellence in their work.\n");
        System.out.print("We have different Outlets that help users in service and maintenance of their vehicles\n");
        System.out.print("anytime and anywhere. Moreover, Users can also share us with data of their vehicles\n");
        System.out.print("and we will give them statistics like mileage and history. Not only, Users can buy some\n");
        System.out.print("spare parts for Vehicles as well.\n\n");
        System.out.print("You can move forward as a\n\n");
        System.out.print("1. Manager\n");
        System.out.print("2. User\n");
        System.out.print("3. Employee/Staff\n");
        System.out.print("4. Exit\n");
    }
}
