public class OutletAdmin extends Manager
{
    public OutletAdmin(int id,String name,String phone,String password,String address,int outletId)
    {
        super(id,name,phone,password,address,outletId);
    }
    public void createOutlet()
    {

    }
    public void updateOutlet()
    {

    }
    public void blockOutlet()
    {

    }
    public void deleteOutlet()
    {

    }
    public void activateUser()
    {

    }
    public void transferUser()
    {

    }
    public void deactivateUser()
    {

    }
}
